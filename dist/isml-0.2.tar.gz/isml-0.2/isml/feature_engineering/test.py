

def test_func(x):
    print(x)